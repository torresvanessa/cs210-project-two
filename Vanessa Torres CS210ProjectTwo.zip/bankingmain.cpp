/*
 * CS 210 Project Two
 * Vanessa Torres
 * Main file for the Airgead Banking application.
 * Handles user input and invokes logic for investment calculations.
 */

#include <iostream>
#include <iomanip>
#include <stdexcept>
#include "banking.h"

using namespace std;

// Function prototypes
int validIntInput();
double validDoubleInput();

int main() {
    // Initialize variables
    Banking myInvestment;
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int years;

    // Prompt the user for input values
    cout << "**********************************" << endl;
    cout << "********** Data Input ************" << endl;
    try {
        cout << "Initial Investment Amount: $";
        initialInvestment = validDoubleInput();
        if (initialInvestment < 0) {
            throw runtime_error("Invalid entry.");
        }
        myInvestment.setInitialInvestment(initialInvestment);

        cout << "Monthly Deposit: $";
        monthlyDeposit = validDoubleInput();
        if (monthlyDeposit < 0) {
            throw runtime_error("Invalid entry.");
        }
        myInvestment.setMonthlyDeposit(monthlyDeposit);

        cout << "Annual Interest: %";
        annualInterest = validDoubleInput();
        if (annualInterest < 0) {
            throw runtime_error("Invalid entry.");
        }
        myInvestment.setAnnualInterest(annualInterest);

        cout << "Number of years: ";
        years = validIntInput();
        if (years <= 0) {
            throw runtime_error("Invalid entry.");
        }
        myInvestment.setNumYears(years);
    }
    catch (runtime_error& excpt) {
        cout << excpt.what() << endl;
        cout << "Cannot compute with negative value." << endl;
        return 1;
    }

    // Print balance without monthly deposits
    cout << endl << "Balance and Interest Without Additional Monthly Deposits" << endl;
    cout << "********************************************************" << endl;
    cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;
    cout << "--------------------------------------------------------" << endl;
    myInvestment.calculateBalanceWithoutMonthlyDeposit(initialInvestment, annualInterest, years);

    // Print balance with monthly deposits
    cout << endl << "Balance and Interest With Additional $" << monthlyDeposit << " Monthly Deposits" << endl;
    cout << "********************************************************" << endl;
    cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;
    cout << "--------------------------------------------------------" << endl;
    myInvestment.balanceWithMonthlyDeposit(initialInvestment, monthlyDeposit, annualInterest, years);

    return 0;
}

// User input validation to make sure input is an integer
int validIntInput() {
    int x;
    while (1) {
        if (cin >> x) {
            // input contains valid number
            break;
        }
        else {
            // not a valid number
            cout << "Invalid Input! Please input a numerical value." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
        }
    }
    return x;
}

// User input validation to make sure input is a double
double validDoubleInput() {
    double x;
    while (1) {
        if (cin >> x) {
            // input contains valid number
            break;
        }
        else {
            // not a valid number
            cout << "Invalid Input! Please enter valid number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
        }
    }
    return x;
}