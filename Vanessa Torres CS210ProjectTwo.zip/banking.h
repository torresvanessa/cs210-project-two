#ifndef BANKING_H
#define BANKING_H

class Banking {
private:
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int numYears;

public:
    // Constructors
    Banking();

    // Setters
    void setInitialInvestment(double initialInvestment);
    void setMonthlyDeposit(double monthlyDeposit);
    void setAnnualInterest(double annualInterest);
    void setNumYears(int numYears);

    // Getters
    double getInitialInvestment() const;
    double getMonthlyDeposit() const;
    double getAnnualInterest() const;
    int getNumYears() const;

    // Function to calculate and output balance without additional monthly deposits
    double calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double annualInterest, int numYears);

    // Function to calculate and output balance with additional monthly deposits
    double balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double annualInterest, int numYears);

    // Function to print investment details
    void printDetails(int year, double yearEndBalance, double interestEarned);
};

#endif