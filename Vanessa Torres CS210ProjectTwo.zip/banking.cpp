/*
 * CS 210 Project Two
 * Vanessa Torres
 * Implementation file for the Banking class.
 * Contains styling functions and definitions for logic functions.
 */

#include "banking.h"
#include <iostream>
#include <iomanip>

using namespace std;

// Constructors
Banking::Banking() : initialInvestment(0.0), monthlyDeposit(0.0), annualInterest(0.0), numYears(0) {}

// Setters
void Banking::setInitialInvestment(double initialInvestment) {
    this->initialInvestment = initialInvestment;
}

void Banking::setMonthlyDeposit(double monthlyDeposit) {
    this->monthlyDeposit = monthlyDeposit;
}

void Banking::setAnnualInterest(double annualInterest) {
    this->annualInterest = annualInterest;
}

void Banking::setNumYears(int numYears) {
    this->numYears = numYears;
}

// Getters
double Banking::getInitialInvestment() const {
    return initialInvestment;
}

double Banking::getMonthlyDeposit() const {
    return monthlyDeposit;
}

double Banking::getAnnualInterest() const {
    return annualInterest;
}

int Banking::getNumYears() const {
    return numYears;
}

// Function to calculate and output balance without additional monthly deposits
double Banking::calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double annualInterest, int numYears) {
    double balance = initialInvestment;
    double interestEarned;

    for (int year = 1; year <= numYears; ++year) {
        interestEarned = balance * (annualInterest / 100.0);
        balance += interestEarned;
        printDetails(year, balance, interestEarned);
    }

    return balance;
}

// Function to calculate and output balance with additional monthly deposits
double Banking::balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double annualInterest, int numYears) {
    double balance = initialInvestment;
    double monthlyInterestRate = annualInterest / 100.0 / 12.0;
    double interestEarned;

    for (int year = 1; year <= numYears; ++year) {
        interestEarned = 0.0;
        for (int month = 1; month <= 12; ++month) {
            balance += monthlyDeposit;
            double monthlyInterest = balance * monthlyInterestRate;
            interestEarned += monthlyInterest;
            balance += monthlyInterest;
        }
        printDetails(year, balance, interestEarned);
    }

    return balance;
}

// Function to print investment details
void Banking::printDetails(int year, double yearEndBalance, double interestEarned) {
    cout << year << "\t$" << fixed << setprecision(2) << yearEndBalance << "\t\t\t$" << interestEarned << endl;
}
